{% docs __overview__ %}

## Data Documentation for Jaffle Shop

`jaffle_shop` is a fictional ecommerce store.

This [dbt](https://www.getdbt.com/) project is for testing out code.

The source code can be found [here](https://github.com/clrcrl/jaffle_shop).

{% enddocs %}
